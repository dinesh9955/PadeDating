package com.padedatingapp.model

data class MeetMeX( val `data`: List<DataX>,
                    val message: String,
                    val statusCode: Int,
                    val success: Boolean,
                    val totalcount: Int

)