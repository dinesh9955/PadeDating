package com.padedatingapp.model

class ImageUploadResponse (
    var source:String,
    var type:String = "",
    var thumb:String = ""
)