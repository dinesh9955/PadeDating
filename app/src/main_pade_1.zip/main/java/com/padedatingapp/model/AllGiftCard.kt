package com.padedatingapp.model

data class AllGiftCard(
    val doc: ArrayList<Doc>,
    val itemCount: Int
)