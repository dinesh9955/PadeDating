package com.padedatingapp.model.reasons

data class Value(
    val id: String,
    val text: String
)