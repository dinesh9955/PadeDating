package com.padedatingapp.model.privacyPolicy

data class PrivacyPolicyModel(
    val `data`: List<Data>,
    val message: String,
    val statusCode: Int
)