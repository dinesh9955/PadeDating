package com.padedatingapp.model

data class UserModelX(
    val `data`: DataXX,
    val message: String,
    val statusCode: Int,
    val success: Boolean
)