package com.padedatingapp.model.user

data class Data(
    val loyaltyPoints: LoyaltyPoints,
    val userData: UserData
)