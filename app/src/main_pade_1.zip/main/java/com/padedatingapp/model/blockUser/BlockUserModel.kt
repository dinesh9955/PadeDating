package com.padedatingapp.model.blockUser

data class BlockUserModel(
    val `data`: Any,
    val message: String,
    val statusCode: Int,
    val success: Boolean
)