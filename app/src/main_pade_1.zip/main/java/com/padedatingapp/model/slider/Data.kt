package com.padedatingapp.model.slider

data class Data(
    val __v: Int,
    val _id: String,
    val createdAt: String,
    val image1: String,
    val image2: String,
    val isDeleted1: Boolean,
    val isDeleted2: Boolean,
    val updatedAt: String
)