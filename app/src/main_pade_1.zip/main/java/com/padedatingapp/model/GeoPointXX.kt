package com.padedatingapp.model

data class GeoPointXX(
    val coordinates: List<Double>,
    val type: String
)