package com.padedatingapp.model.notification

data class User2(
    val _id: String,
    val firstName: String,
    val image: String,
    val lastName: String
)