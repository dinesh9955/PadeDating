package com.padedatingapp.interfaces

interface GetLocation{
        fun getLocation(address : String){}
}