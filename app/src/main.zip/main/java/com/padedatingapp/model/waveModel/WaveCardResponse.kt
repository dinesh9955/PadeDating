package com.padedatingapp.model.waveModel

data class WaveCardResponse(
    val `data`: Data,
    val message: String,
    val meta: Meta,
    val status: String
)