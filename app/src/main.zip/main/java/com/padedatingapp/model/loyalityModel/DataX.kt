package com.padedatingapp.model.loyalityModel

data class DataX(
    val Points: Int,
    val __v: Int,
    val _id: String,
    val createdAt: String,
    val isDeleted: Boolean,
    val type: String,
    val updatedAt: String,
    val user: String
)