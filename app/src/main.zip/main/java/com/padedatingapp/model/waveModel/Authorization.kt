package com.padedatingapp.model.waveModel

data class Authorization(
    val endpoint: String,
    val mode: String
)