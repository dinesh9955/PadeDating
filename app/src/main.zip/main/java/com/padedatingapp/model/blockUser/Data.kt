package com.padedatingapp.model.blockUser

data class Data(
    val _id: String,
    val age: Int,
    val country: String,
    val countryCode: String,
    val email: String,
    val firstName: String,
    val gender: String,
    val image: String,
    val lastName: String,
    val phoneNo: String
)