package com.padedatingapp.model

data class ImageModel (
    var source:String,
    var type:String="",
    var thumb:String=""
)