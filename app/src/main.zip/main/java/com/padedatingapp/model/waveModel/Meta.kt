package com.padedatingapp.model.waveModel

data class Meta(
    val authorization: Authorization
)