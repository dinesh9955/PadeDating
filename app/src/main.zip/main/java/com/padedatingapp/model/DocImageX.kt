package com.padedatingapp.model

data class DocImageX(
    val _id: String,
    val source: String,
    val thumb: Any,
    val type: String
)