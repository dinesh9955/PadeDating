package com.padedatingapp.model.reasons

data class Data(
    val __v: Int,
    val _id: String,
    val key: String,
    val value: ArrayList<Value> = ArrayList()
)