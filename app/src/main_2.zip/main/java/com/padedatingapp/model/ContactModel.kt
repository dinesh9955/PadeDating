package com.padedatingapp.model

data class ContactModel(
    val cardTop: ContactCardModel,
    val cardBottom:ContactCardModel
)
