package com.padedatingapp.model.loyalityModel

data class LoyalityPointsResponse(
    val `data`: Data,
    val message: String,
    val statusCode: Int,
    val success: Boolean
)