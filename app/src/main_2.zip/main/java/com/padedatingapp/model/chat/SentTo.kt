package com.padedatingapp.model.chat

data class SentTo(
    val _id: String,
    val firstName: String,
    val image: String,
    val lastName: String
)