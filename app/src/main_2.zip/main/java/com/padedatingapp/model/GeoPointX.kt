package com.padedatingapp.model

data class GeoPointX(
    val coordinates: List<Double>,
    val type: String
)