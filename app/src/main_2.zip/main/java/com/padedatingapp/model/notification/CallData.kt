package com.padedatingapp.model.notification

data class CallData(
    val apikey: String,
    val sessionId: String,
    val token: String
)