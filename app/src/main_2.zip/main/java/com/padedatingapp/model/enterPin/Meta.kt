package com.padedatingapp.model.enterPin

data class Meta(
    val authorization: Authorization
)