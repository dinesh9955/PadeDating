package com.padedatingapp.model.enterPin

data class Authorization(
    val endpoint: String,
    val mode: String
)