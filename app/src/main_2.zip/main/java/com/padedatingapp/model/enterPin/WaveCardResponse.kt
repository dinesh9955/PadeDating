package com.padedatingapp.model.enterPin

data class WaveCardResponse(
    val `data`: Data,
    val message: String,
    val meta: Meta,
    val status: String
)