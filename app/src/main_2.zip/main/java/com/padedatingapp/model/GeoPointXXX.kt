package com.padedatingapp.model

data class GeoPointXXX(
    val coordinates: List<Double>,
    val type: String
)