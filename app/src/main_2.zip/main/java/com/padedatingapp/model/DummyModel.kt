package com.padedatingapp.model

class DummyModel {
}