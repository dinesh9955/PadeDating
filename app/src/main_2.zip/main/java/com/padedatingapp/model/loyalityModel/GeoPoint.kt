package com.padedatingapp.model.loyalityModel

data class GeoPoint(
    val coordinates: List<Double>,
    val type: String
)