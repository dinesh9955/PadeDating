package com.padedatingapp.model

class OtpData(val oneTimeCode:Int)