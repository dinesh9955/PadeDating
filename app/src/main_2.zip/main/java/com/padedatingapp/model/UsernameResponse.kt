package com.padedatingapp.model

data class UsernameResponse(
    var isAvailable: Boolean = false
)