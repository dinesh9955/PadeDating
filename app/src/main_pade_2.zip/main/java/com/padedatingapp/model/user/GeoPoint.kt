package com.padedatingapp.model.user

data class GeoPoint(
    val coordinates: List<Int>,
    val type: String
)