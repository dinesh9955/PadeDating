package com.padedatingapp.model.notification

data class User1(
    val _id: String,
    val firstName: String,
    val image: String,
    val lastName: String
)