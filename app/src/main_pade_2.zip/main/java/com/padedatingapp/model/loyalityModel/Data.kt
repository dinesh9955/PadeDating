package com.padedatingapp.model.loyalityModel

data class Data(
    val UserPoints: UserPoints,
    val `data`: List<DataX>,
    val discount: Double
)