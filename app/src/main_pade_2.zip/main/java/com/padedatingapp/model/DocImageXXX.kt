package com.padedatingapp.model

data class DocImageXXX(
    val _id: String,
    val source: String,
    val thumb: Any,
    val type: String
)