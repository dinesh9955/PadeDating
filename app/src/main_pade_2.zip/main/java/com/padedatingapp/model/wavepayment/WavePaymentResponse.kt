package com.padedatingapp.model.wavepayment

data class WavePaymentResponse(
    val `data`: Data,
    val message: String,
    val status: String
)