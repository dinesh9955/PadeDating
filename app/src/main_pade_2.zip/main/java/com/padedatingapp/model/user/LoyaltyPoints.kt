package com.padedatingapp.model.user

data class LoyaltyPoints(
    val totalPoints: Int,
    val user: String
)