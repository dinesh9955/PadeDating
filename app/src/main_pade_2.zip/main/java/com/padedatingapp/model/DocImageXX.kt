package com.padedatingapp.model

data class DocImageXX(
    val _id: String,
    val source: String,
    val thumb: Any,
    val type: String
)