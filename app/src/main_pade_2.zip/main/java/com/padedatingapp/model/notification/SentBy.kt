package com.padedatingapp.model.notification

data class SentBy(
    val _id: String,
    val firstName: String,
    val image: String,
    val lastName: String
)